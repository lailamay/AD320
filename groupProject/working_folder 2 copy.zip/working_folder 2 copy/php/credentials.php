<?php
  $servername = "localhost";
  $username = "root";
  $password = "Barsik_71";
  $dbname = "fitness_tracker";
  ?>
